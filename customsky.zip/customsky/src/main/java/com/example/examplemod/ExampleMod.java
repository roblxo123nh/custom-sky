package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.client.gui.screens.Screen;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import com.example.examplemod.gui.SkyScreen;
import com.example.examplemod.config.ModConfig;
import net.minecraftforge.client.event.CustomizeGuiOverlayEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.client.event.TextureStitchEvent;
import net.minecraft.world.level.Level;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Mod("skychanger")
public class ExampleMod {
    public static final String MOD_ID = "skychanger";
    public static final String MODID = MOD_ID;
    public static final String SKY_TEXTURES_DIR = "textures";
    private static final Logger LOGGER = LogManager.getLogger();
    private static KeyMapping openGuiKey;
    private static SkyRenderer skyRenderer;
    
    public ExampleMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        // Регистрируем обработчики событий
        MinecraftForge.EVENT_BUS.register(this);
        modEventBus.addListener(this::clientSetup);
        
        // Важно: регистрируем обработчик клавиш на modEventBus
        modEventBus.addListener(this::registerKeyBinds);
        
        // Регистрируем конфигурацию
        ModConfig.register();
    }
    
    @SubscribeEvent
    public void clientSetup(final FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            // Создаем рендерер
            skyRenderer = new SkyRenderer();
            
            // Загружаем сохраненную текстуру
            String savedTexture = ModConfig.CURRENT_TEXTURE.get();
            if (!savedTexture.isEmpty()) {
                File textureFile = new File(TextureManager.getTexturesDirectory(), savedTexture);
                if (textureFile.exists()) {
                    TextureManager.getInstance().loadAndSetTexture(textureFile);
                }
            }
            
            // Инициализируем менеджер текстур
            TextureManager.getInstance().initialize();
        });
    }
    
    @SubscribeEvent
    public void onResourceReload(TextureStitchEvent.Post event) {
        TextureManager.getInstance().initialize();
    }
    
    // Изменяем метод регистрации клавиш
    private void registerKeyBinds(RegisterKeyMappingsEvent event) {
        openGuiKey = new KeyMapping(
            "key.skychanger.open_gui",
            GLFW.GLFW_KEY_K,
            "key.categories.skychanger"
        );
        event.register(openGuiKey);
    }
    
    // Изменяем метод обработки нажатия клавиш
    @SubscribeEvent
    public void onKeyInput(InputEvent.Key event) {
        if (openGuiKey != null && openGuiKey.consumeClick()) {
            Minecraft.getInstance().setScreen(new SkyScreen());
        }
    }
    
    @SubscribeEvent
    public void onRenderSky(net.minecraftforge.client.event.RenderLevelStageEvent event) {
        if (event.getStage() == net.minecraftforge.client.event.RenderLevelStageEvent.Stage.AFTER_SKY) {
            if (skyRenderer != null) {
                Level level = Minecraft.getInstance().level;
                if (level != null) {
                    skyRenderer.render(event.getPoseStack(), 
                                     event.getProjectionMatrix(), 
                                     event.getPartialTick(), 
                                     Minecraft.getInstance(), 
                                     level);
                }
            }
        }
    }
    
    public static SkyRenderer getSkyRenderer() {
        return skyRenderer;
    }
} 