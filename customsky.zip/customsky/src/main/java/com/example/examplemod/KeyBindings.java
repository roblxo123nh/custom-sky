package com.example.examplemod;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ExampleMod.MOD_ID, value = Dist.CLIENT)
public class KeyBindings {
    public static final KeyMapping TOGGLE_SKY_MODE = new KeyMapping(
        "key.examplemod.toggle_sky_mode", // Ключ перевода
        GLFW.GLFW_KEY_M,                 // Клавиша M по умолчанию
        "key.categories.examplemod"       // Категория в настройках
    );

    @SubscribeEvent
    public static void registerKeyBindings(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_SKY_MODE);
    }
} 