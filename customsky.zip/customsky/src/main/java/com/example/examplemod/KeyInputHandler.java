package com.example.examplemod;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

@Mod.EventBusSubscriber(modid = ExampleMod.MOD_ID, value = Dist.CLIENT)
public class KeyInputHandler {
    
    @SubscribeEvent
    @OnlyIn(Dist.CLIENT)
    public static void onKeyInput(InputEvent.Key event) {
        if (KeyBindings.TOGGLE_SKY_MODE.consumeClick()) {
            // Получаем экземпляр SkyRenderer из вашего основного класса мода
            SkyRenderer skyRenderer = ExampleMod.getSkyRenderer();
            if (skyRenderer != null) {
                skyRenderer.toggleRenderMode();
                // Отправляем сообщение в чат о смене режима
                Minecraft.getInstance().player.displayClientMessage(
                    Component.translatable("message.examplemod.sky_mode_changed"), 
                    true
                );
            }
        }
    }
} 