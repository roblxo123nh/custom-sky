package com.example.examplemod;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public class SkyRenderer {
    private final ResourceLocation skyTexture;
    private static final Logger LOGGER = LogManager.getLogger();
    private SkyTexture previousTexture;
    private float transitionProgress = 1.0f;
    private static final float TRANSITION_SPEED = 0.05f;
    
    private static final int HORIZONTAL_SEGMENTS = 32;
    private static final int VERTICAL_SEGMENTS = 16;   
    private static final float RADIUS = 100.0F;
    private static final float Y_OFFSET = -10.0F;
    
    private DynamicTexture currentDynamicTexture;
    private long lastTextureUpdate;
    private static final long TEXTURE_UPDATE_INTERVAL = 50;
    
    private boolean useCubeMode = false;
    
    public SkyRenderer() {
        skyTexture = new ResourceLocation(ExampleMod.MOD_ID, "sky");
    }
    
    public void render(PoseStack matrixStack, Matrix4f projectionMatrix, float partialTicks, 
                      Minecraft minecraft, Level level) {
        try {
            renderSky(matrixStack, projectionMatrix, partialTicks, minecraft, level);
        } catch (Exception e) {
            LOGGER.error("Failed to render custom sky texture", e);
        }
    }
    
    private void renderSky(PoseStack matrixStack, Matrix4f projectionMatrix, float partialTicks, 
                          Minecraft minecraft, Level level) {
        SkyTexture currentTexture = TextureManager.getInstance().getCurrentTexture();
        
        if (currentTexture != previousTexture) {
            if (currentDynamicTexture != null) {
                currentDynamicTexture.close();
                currentDynamicTexture = null;
            }
            previousTexture = currentTexture;
            transitionProgress = 1.0f;
        }

        if (currentTexture != null) {
            renderTexturedSky(currentTexture, transitionProgress, matrixStack, minecraft);
            transitionProgress = Math.min(1.0f, transitionProgress + TRANSITION_SPEED);
        }
    }

    private void renderTexturedSky(SkyTexture texture, float alpha, PoseStack matrixStack, Minecraft minecraft) {
        if (texture == null) return;
        
        long currentTime = System.currentTimeMillis();
        boolean needsUpdate = texture.isAnimated() && 
                             (currentDynamicTexture == null || currentTime - lastTextureUpdate > TEXTURE_UPDATE_INTERVAL);
        
        if (currentDynamicTexture == null || needsUpdate) {
            if (currentDynamicTexture != null) {
                currentDynamicTexture.close();
                minecraft.getTextureManager().release(skyTexture);
            }
            
            NativeImage frame = texture.getCurrentFrame();
            if (frame != null) {
                try {
                    NativeImage frameCopy = new NativeImage(
                        frame.format(),
                        frame.getWidth(),
                        frame.getHeight(),
                        false
                    );
                    frameCopy.copyFrom(frame);
                    currentDynamicTexture = new DynamicTexture(frameCopy);
                    minecraft.getTextureManager().register(skyTexture, currentDynamicTexture);
                    lastTextureUpdate = currentTime;
                    
                    RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
                    RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
                    RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_CLAMP);
                    RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_CLAMP);
                } catch (Exception e) {
                    LOGGER.error("Failed to update sky texture", e);
                    return;
                }
            }
        }
        
        try {
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderTexture(0, skyTexture);
            
            matrixStack.pushPose();
            
            float timeRotation = (minecraft.level.getDayTime() % 24000) / 24000.0F * 360.0F;
            matrixStack.mulPose(com.mojang.math.Axis.XP.rotationDegrees(30.0F));
            matrixStack.mulPose(com.mojang.math.Axis.YP.rotationDegrees(timeRotation));
            
            int color = 0xFFFFFFFF;
            
            if (useCubeMode) {
                renderCube(matrixStack, color);
            } else {
                renderDome(matrixStack, color);
            }
            
            matrixStack.popPose();
            
        } finally {
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
            RenderSystem.enableDepthTest();
        }
    }
    
    private void renderDome(PoseStack matrixStack, int color) {
        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder bufferBuilder = tesselator.getBuilder();
        
        bufferBuilder.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_TEX_COLOR);
        
        for (int y = 0; y < VERTICAL_SEGMENTS; y++) {
            float phi1 = (float) ((y * Math.PI / VERTICAL_SEGMENTS) - Math.PI/2);
            float phi2 = (float) (((y + 1) * Math.PI / VERTICAL_SEGMENTS) - Math.PI/2);
            float v1 = (float) y / VERTICAL_SEGMENTS;
            float v2 = (float) (y + 1) / VERTICAL_SEGMENTS;
            
            for (int x = 0; x < HORIZONTAL_SEGMENTS; x++) {
                float theta1 = (float) (x * 2 * Math.PI / HORIZONTAL_SEGMENTS);
                float theta2 = (float) ((x + 1) * 2 * Math.PI / HORIZONTAL_SEGMENTS);
                float u1 = (float) x / HORIZONTAL_SEGMENTS;
                float u2 = (float) (x + 1) / HORIZONTAL_SEGMENTS;
                
                addDomeVertex(bufferBuilder, matrixStack, theta1, phi1, u1, v1, color);
                addDomeVertex(bufferBuilder, matrixStack, theta2, phi1, u2, v1, color);
                addDomeVertex(bufferBuilder, matrixStack, theta1, phi2, u1, v2, color);
                
                addDomeVertex(bufferBuilder, matrixStack, theta2, phi1, u2, v1, color);
                addDomeVertex(bufferBuilder, matrixStack, theta2, phi2, u2, v2, color);
                addDomeVertex(bufferBuilder, matrixStack, theta1, phi2, u1, v2, color);
            }
        }
        
        tesselator.end();
    }
    
    private void addDomeVertex(BufferBuilder buffer, PoseStack matrixStack, 
                             float theta, float phi, float u, float v, int color) {
        float x = (float) (RADIUS * Math.cos(phi) * Math.cos(theta));
        float y = (float) (RADIUS * Math.sin(phi));
        float z = (float) (RADIUS * Math.cos(phi) * Math.sin(theta));
        
        buffer.vertex(matrixStack.last().pose(), x, y + Y_OFFSET, z)
            .uv(u, v)
            .color(color)
            .endVertex();
    }

    public void toggleRenderMode() {
        useCubeMode = !useCubeMode;
    }

    private void renderCube(PoseStack matrixStack, int color) {
        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder bufferBuilder = tesselator.getBuilder();
        float size = RADIUS;
        
        // Используем QUADS для более точного рендеринга граней
        bufferBuilder.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
        
        // Передняя грань (Z-)
        bufferBuilder.vertex(matrixStack.last().pose(), -size, -size, -size).uv(0, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, -size, -size).uv(1, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, size, -size).uv(1, 0).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, size, -size).uv(0, 0).color(color).endVertex();

        // Задняя грань (Z+)
        bufferBuilder.vertex(matrixStack.last().pose(), size, -size, size).uv(0, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, -size, size).uv(1, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, size, size).uv(1, 0).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, size, size).uv(0, 0).color(color).endVertex();

        // Верхняя грань (Y+)
        bufferBuilder.vertex(matrixStack.last().pose(), -size, size, -size).uv(0, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, size, -size).uv(1, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, size, size).uv(1, 0).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, size, size).uv(0, 0).color(color).endVertex();

        // Нижняя грань (Y-)
        bufferBuilder.vertex(matrixStack.last().pose(), -size, -size, -size).uv(0, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, -size, size).uv(1, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, -size, size).uv(1, 0).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, -size, -size).uv(0, 0).color(color).endVertex();

        // Правая грань (X+)
        bufferBuilder.vertex(matrixStack.last().pose(), size, -size, -size).uv(0, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, -size, size).uv(1, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, size, size).uv(1, 0).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), size, size, -size).uv(0, 0).color(color).endVertex();

        // Левая грань (X-)
        bufferBuilder.vertex(matrixStack.last().pose(), -size, -size, size).uv(0, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, -size, -size).uv(1, 1).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, size, -size).uv(1, 0).color(color).endVertex();
        bufferBuilder.vertex(matrixStack.last().pose(), -size, size, size).uv(0, 0).color(color).endVertex();

        tesselator.end();
    }
    
    public void close() {
        if (currentDynamicTexture != null) {
            currentDynamicTexture.close();
            currentDynamicTexture = null;
        }
    }
} 