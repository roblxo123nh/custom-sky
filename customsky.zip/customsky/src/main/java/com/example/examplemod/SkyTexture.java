package com.example.examplemod;

import com.mojang.blaze3d.platform.NativeImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.metadata.IIOMetadataNode;
import org.w3c.dom.NodeList;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.stream.ImageInputStream;

public class SkyTexture {
    private final String name;
    private final boolean isAnimated;
    private final List<NativeImage> frames;
    private final List<Integer> frameDelays;
    private long lastFrameTime;
    private int currentFrame;
    
    public SkyTexture(File file) throws IOException {
        this.name = file.getName();
        this.frames = new ArrayList<>();
        this.frameDelays = new ArrayList<>();
        
        String extension = name.toLowerCase();
        this.isAnimated = extension.endsWith(".gif");
        
        if (this.isAnimated) {
            loadGif(file);
        } else if (extension.endsWith(".jpg") || extension.endsWith(".jpeg") || extension.endsWith(".png")) {
            loadStaticImage(file);
        } else {
            throw new IOException("Unsupported file format: " + extension);
        }
    }
    
    private void loadGif(File file) throws IOException {
        ImageReader reader = ImageIO.getImageReadersByFormatName("gif").next();
        ImageInputStream stream = ImageIO.createImageInputStream(file);
        reader.setInput(stream);
        
        int frameCount = reader.getNumImages(true);
        
        // Читаем все кадры и их задержки
        for (int i = 0; i < frameCount; i++) {
            // Получаем метаданные для текущего кадра
            IIOMetadata metadata = reader.getImageMetadata(i);
            String metaFormatName = metadata.getNativeMetadataFormatName();
            IIOMetadataNode root = (IIOMetadataNode) metadata.getAsTree(metaFormatName);
            
            // Читаем задержку из метаданных текущего кадра
            IIOMetadataNode gce = findNode(root, "GraphicControlExtension");
            int delay = Integer.parseInt(gce.getAttribute("delayTime"));
            // Если задержка слишком маленькая или отсутствует, используем стандартную
            if (delay < 1) delay = 10;
            frameDelays.add(delay * 10); // Конвертируем в миллисекунды
            
            // Читаем и обрабатываем кадр
            BufferedImage frame = reader.read(i);
            BufferedImage convertedFrame = new BufferedImage(
                frame.getWidth(), 
                frame.getHeight(), 
                BufferedImage.TYPE_INT_ARGB
            );
            
            // Получаем информацию о прозрачности
            int transparentColor = -1;
            String transparentColorStr = gce.getAttribute("transparentColorIndex");
            if (transparentColorStr != null && !transparentColorStr.isEmpty()) {
                transparentColor = Integer.parseInt(transparentColorStr);
            }
            
            // Копируем изображение с учетом прозрачности
            for (int y = 0; y < frame.getHeight(); y++) {
                for (int x = 0; x < frame.getWidth(); x++) {
                    int rgb = frame.getRGB(x, y);
                    if ((rgb & 0xFF000000) == 0 || (transparentColor >= 0 && (rgb & 0xFF) == transparentColor)) {
                        // Если пиксель прозрачный или соответствует прозрачному цвету
                        if (frames.size() > 0) {
                            // Используем пиксель из предыдущего кадра
                            convertedFrame.setRGB(x, y, frames.get(frames.size() - 1).getPixelRGBA(x, y));
                        } else {
                            // Для первого кадра используем полностью прозрачный пиксель
                            convertedFrame.setRGB(x, y, 0);
                        }
                    } else {
                        convertedFrame.setRGB(x, y, rgb | 0xFF000000);
                    }
                }
            }
            
            NativeImage nativeImage = new NativeImage(
                NativeImage.Format.RGBA, 
                convertedFrame.getWidth(), 
                convertedFrame.getHeight(), 
                false
            );
            
            // Копируем пиксели в NativeImage
            for (int x = 0; x < convertedFrame.getWidth(); x++) {
                for (int y = 0; y < convertedFrame.getHeight(); y++) {
                    int argb = convertedFrame.getRGB(x, y);
                    nativeImage.setPixelRGBA(x, y, 
                        ((argb >> 24) & 0xFF) << 24 | // Alpha
                        ((argb >> 16) & 0xFF) << 16 | // Red
                        ((argb >> 8) & 0xFF) << 8 |   // Green
                        (argb & 0xFF));               // Blue
                }
            }
            frames.add(nativeImage);
        }
        reader.dispose();
        stream.close();
    }
    
    private void loadStaticImage(File file) throws IOException {
        BufferedImage image = ImageIO.read(file);
        
        // Проверяем размер изображения и масштабируем если нужно
        int maxSize = 2048; // Максимальный размер текстуры
        if (image.getWidth() > maxSize || image.getHeight() > maxSize) {
            // Вычисляем новые размеры, сохраняя пропорции
            double scale = Math.min(
                (double) maxSize / image.getWidth(),
                (double) maxSize / image.getHeight()
            );
            
            int newWidth = (int) (image.getWidth() * scale);
            int newHeight = (int) (image.getHeight() * scale);
            
            // Создаем новое изображение с нужным размером
            BufferedImage resized = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
            java.awt.Graphics2D g = resized.createGraphics();
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, 
                              java.awt.RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
            g.drawImage(image, 0, 0, newWidth, newHeight, null);
            g.dispose();
            
            image = resized;
        }
        
        // Конвертируем в ARGB если нужно
        if (image.getType() != BufferedImage.TYPE_INT_ARGB) {
            BufferedImage convertedImage = new BufferedImage(
                image.getWidth(), 
                image.getHeight(), 
                BufferedImage.TYPE_INT_ARGB
            );
            java.awt.Graphics2D g = convertedImage.createGraphics();
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, 
                              java.awt.RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
            g.drawImage(image, 0, 0, null);
            g.dispose();
            image = convertedImage;
        }
        
        NativeImage nativeImage = new NativeImage(
            NativeImage.Format.RGBA,
            image.getWidth(),
            image.getHeight(),
            false
        );
        
        // Копируем пиксели напрямую
        for (int x = 0; x < image.getWidth(); x++) {
            for (int y = 0; y < image.getHeight(); y++) {
                int argb = image.getRGB(x, y);
                // Преобразуем ARGB в ABGR (нативный формат OpenGL)
                int r = (argb >> 16) & 0xFF;
                int g = (argb >> 8) & 0xFF;
                int b = argb & 0xFF;
                int a = (argb >> 24) & 0xFF;
                int abgr = (a << 24) | (b << 16) | (g << 8) | r;
                nativeImage.setPixelRGBA(x, y, abgr);
            }
        }
        frames.add(nativeImage);
        frameDelays.add(0);
    }
    
    private static IIOMetadataNode findNode(IIOMetadataNode rootNode, String nodeName) {
        for (int i = 0; i < rootNode.getLength(); i++) {
            if (rootNode.item(i).getNodeName().equalsIgnoreCase(nodeName)) {
                return (IIOMetadataNode) rootNode.item(i);
            }
        }
        IIOMetadataNode node = new IIOMetadataNode(nodeName);
        rootNode.appendChild(node);
        return node;
    }
    
    public String getName() {
        return name;
    }
    
    public boolean isAnimated() {
        return isAnimated;
    }
    
    public NativeImage getCurrentFrame() {
        if (isAnimated && frames.size() > 1) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastFrameTime > frameDelays.get(currentFrame)) {
                currentFrame = (currentFrame + 1) % frames.size();
                lastFrameTime = currentTime;
            }
        }
        return frames.get(currentFrame);
    }
    
    public void close() {
        for (NativeImage frame : frames) {
            frame.close();
        }
        frames.clear();
    }
    
    @Override
    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
} 