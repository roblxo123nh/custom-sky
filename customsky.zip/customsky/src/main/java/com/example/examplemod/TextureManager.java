package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.example.examplemod.config.ModConfig;

public class TextureManager {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final int MAX_PNG_SIZE = 2048;
    private static final int MAX_GIF_SIZE = 1024;
    private static final long CACHE_TIMEOUT = 5 * 60 * 1000; // 5 минут
    
    private static TextureManager instance;
    private final Map<String, SkyTexture> textureCache;
    private final Map<String, Long> lastAccessTimes;
    private SkyTexture currentTexture;

    private TextureManager() {
        textureCache = new HashMap<>();
        lastAccessTimes = new HashMap<>();
        currentTexture = null;
    }

    public static TextureManager getInstance() {
        if (instance == null) {
            instance = new TextureManager();
        }
        return instance;
    }

    public void initialize() {
        loadTextures();
    }

    private void loadTextures() {
        Path skyTexturesPath = getTexturesPath();
        File directory = skyTexturesPath.toFile();
        if (!directory.exists()) {
            directory.mkdirs();
            return;
        }

        File[] files = directory.listFiles((dir, name) -> {
            String lower = name.toLowerCase();
            return lower.endsWith(".png") || 
                   lower.endsWith(".gif") || 
                   lower.endsWith(".jpg") || 
                   lower.endsWith(".jpeg");
        });

        if (files != null) {
            for (File file : files) {
                try {
                    loadTexture(file);
                } catch (Exception e) {
                    LOGGER.error("Failed to load texture: " + file.getName(), e);
                }
            }
        }
    }

    public void loadTexture(File file) throws Exception {
        String extension = getFileExtension(file.getName());
        if (extension.equals("png")) {
            loadPngTexture(file);
        } else if (extension.equals("gif")) {
            loadGifTexture(file);
        }
    }

    private void loadPngTexture(File file) throws Exception {
        BufferedImage image = ImageIO.read(file);
        
        if (image.getWidth() > MAX_PNG_SIZE || image.getHeight() > MAX_PNG_SIZE) {
            LOGGER.warn("Image too large, resizing: " + file.getName());
            image = resizeImage(image, MAX_PNG_SIZE);
        }
        
        textureCache.put(file.getName(), new SkyTexture(file));
        lastAccessTimes.put(file.getName(), System.currentTimeMillis());
    }

    private void loadGifTexture(File file) throws Exception {
        textureCache.put(file.getName(), new SkyTexture(file));
        lastAccessTimes.put(file.getName(), System.currentTimeMillis());
    }

    private static String getFileExtension(String filename) {
        return filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
    }

    public SkyTexture getTexture(String name) {
        SkyTexture texture = textureCache.get(name);
        if (texture != null) {
            lastAccessTimes.put(name, System.currentTimeMillis());
        }
        return texture;
    }

    public File[] getTextureFiles() {
        File directory = getTexturesPath().toFile();
        return directory.listFiles((dir, name) -> 
            name.toLowerCase().endsWith(".png") || name.toLowerCase().endsWith(".gif"));
    }

    public void loadAndSetTexture(File file) {
        try {
            loadTexture(file);
            currentTexture = getTexture(file.getName());
        } catch (Exception e) {
            LOGGER.error("Failed to load and set texture: " + file.getName(), e);
        }
    }

    public SkyTexture getCurrentTexture() {
        return currentTexture;
    }

    public void setCurrentTexture(SkyTexture texture) {
        currentTexture = texture;
        if (texture != null) {
            ModConfig.CURRENT_TEXTURE.set(texture.getName());
        } else {
            ModConfig.CURRENT_TEXTURE.set("");
        }
        ModConfig.SPEC.save();
    }

    private BufferedImage resizeImage(BufferedImage originalImage, int maxSize) {
        double scale = Math.min(
            (double) maxSize / originalImage.getWidth(),
            (double) maxSize / originalImage.getHeight()
        );
        
        int targetWidth = (int) (originalImage.getWidth() * scale);
        int targetHeight = (int) (originalImage.getHeight() * scale);
        
        java.awt.Image resultingImage = originalImage.getScaledInstance(
            targetWidth, targetHeight, java.awt.Image.SCALE_SMOOTH);
        BufferedImage outputImage = new BufferedImage(
            targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
        
        java.awt.Graphics2D g2d = outputImage.createGraphics();
        g2d.drawImage(resultingImage, 0, 0, null);
        g2d.dispose();
        
        return outputImage;
    }

    private static Path getTexturesPath() {
        return Minecraft.getInstance().gameDirectory.toPath()
            .resolve("config")
            .resolve(ExampleMod.MOD_ID)
            .resolve("textures");
    }

    public void cleanupCache() {
        long currentTime = System.currentTimeMillis();
        Iterator<Map.Entry<String, Long>> iterator = lastAccessTimes.entrySet().iterator();
        
        while (iterator.hasNext()) {
            Map.Entry<String, Long> entry = iterator.next();
            if (currentTime - entry.getValue() > CACHE_TIMEOUT) {
                String textureName = entry.getKey();
                SkyTexture texture = textureCache.remove(textureName);
                if (texture != null) {
                    texture.close();
                }
                iterator.remove();
            }
        }
    }

    public static File getTexturesDirectory() {
        File directory = getTexturesPath().toFile();
        if (!directory.exists()) {
            directory.mkdirs();
        }
        return directory;
    }

    public void reloadTextures() {
        textureCache.clear();
        lastAccessTimes.clear();
        loadTextures();
    }
} 