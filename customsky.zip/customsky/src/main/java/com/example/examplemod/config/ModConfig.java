package com.example.examplemod.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig.Type;

public class ModConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    
    public static final ForgeConfigSpec.ConfigValue<String> CURRENT_TEXTURE = BUILDER
        .comment("The filename of the currently selected sky texture")
        .define("currentTexture", "");
        
    public static final ForgeConfigSpec.IntValue MAX_TEXTURE_SIZE = BUILDER
        .comment("Maximum allowed texture size (width/height) in pixels")
        .defineInRange("maxTextureSize", 2048, 256, 4096);
        
    public static final ForgeConfigSpec.IntValue GIF_FRAME_DELAY = BUILDER
        .comment("Default delay between GIF frames in milliseconds (if not specified in the file)")
        .defineInRange("gifFrameDelay", 100, 16, 1000);
        
    public static final ForgeConfigSpec SPEC = BUILDER.build();
    
    public static void register() {
        ModLoadingContext.get().registerConfig(Type.CLIENT, SPEC, "skychanger-client.toml");
    }
} 