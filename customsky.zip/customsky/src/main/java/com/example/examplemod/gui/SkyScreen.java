package com.example.examplemod.gui;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import com.example.examplemod.TextureManager;
import com.example.examplemod.SkyTexture;
import com.example.examplemod.ExampleMod;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

public class SkyScreen extends Screen {
    private List<TextureButton> textureButtons = new ArrayList<>();
    private int scrollOffset = 0;
    private static final int BUTTONS_PER_PAGE = 6;
    private static final int PREVIEW_SIZE = 32;
    private static final ResourceLocation WIDGETS_LOCATION = 
        new ResourceLocation(ExampleMod.MOD_ID, "textures/gui/widgets.png");
    
    private Button scrollUpButton;
    private Button scrollDownButton;
    private Button resetButton;
    private int selectedIndex = -1;
    
    public SkyScreen() {
        super(Component.translatable("screen.skychanger.title"));
    }
    
    @Override
    protected void init() {
        // Кнопка для возврата к стандартному небу
        resetButton = Button.builder(
            Component.translatable("button.skychanger.reset"),
            button -> {
                TextureManager.getInstance().setCurrentTexture(null);
                selectedIndex = -1;
                this.onClose();
            })
            .pos(this.width / 2 - 100, this.height - 30)
            .size(200, 20)
            .build();
        this.addRenderableWidget(resetButton);
            
        // Кнопки прокрутки
        scrollUpButton = Button.builder(
            Component.literal("↑"),
            button -> {
                scrollOffset = Math.max(0, scrollOffset - 1);
                updateTextureButtons();
            })
            .pos(this.width - 30, 20)
            .size(20, 20)
            .build();
        this.addRenderableWidget(scrollUpButton);
            
        scrollDownButton = Button.builder(
            Component.literal("↓"),
            button -> {
                File[] files = TextureManager.getInstance().getTextureFiles();
                if (files != null && files.length > scrollOffset + BUTTONS_PER_PAGE) {
                    scrollOffset++;
                    updateTextureButtons();
                }
            })
            .pos(this.width - 30, this.height - 40)
            .size(20, 20)
            .build();
        this.addRenderableWidget(scrollDownButton);
            
        // Создаем кнопки для текстур
        updateTextureButtons();
        
        // Подсказки по горячим клавишам
        String currentTexture = TextureManager.getInstance().getCurrentTexture() != null ? 
            TextureManager.getInstance().getCurrentTexture().getName() : "None";
        this.addRenderableWidget(Button.builder(
            Component.literal("Current: " + currentTexture),
            button -> {})
            .pos(10, this.height - 30)
            .size(150, 20)
            .build());
    }
    
    private void updateTextureButtons() {
        textureButtons.forEach(this::removeWidget);
        textureButtons.clear();
        
        File[] textureFiles = TextureManager.getInstance().getTextureFiles();
        if (textureFiles != null) {
            int y = 40;
            for (int i = scrollOffset; i < Math.min(textureFiles.length, scrollOffset + BUTTONS_PER_PAGE); i++) {
                final int index = i;
                File file = textureFiles[i];
                TextureButton button = new TextureButton(
                    this.width / 2 - 100, y, 200, 20,
                    Component.literal(file.getName()),
                    file,
                    btn -> {
                        TextureManager.getInstance().loadAndSetTexture(file);
                        selectedIndex = index;
                        this.onClose();
                    });
                
                if (index == selectedIndex) {
                    button.setSelected(true);
                }
                
                textureButtons.add(button);
                this.addRenderableWidget(button);
                y += 25;
            }
        }
    }
    
    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.renderBackground(guiGraphics);
        
        // Рендерим заголовок
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 10, 0xFFFFFF);
        
        // Рендерим подсказки
        guiGraphics.drawString(this.font, "Press K to open this screen", 10, 10, 0xAAAAAA);
        guiGraphics.drawString(this.font, "Use number keys 1-9 to quick select", 10, 20, 0xAAAAAA);
        
        super.render(guiGraphics, mouseX, mouseY, partialTicks);
        
        // Рендерим превью
        for (TextureButton button : textureButtons) {
            if (button.isHovered()) {
                renderTexturePreview(guiGraphics, button.getTexture(), mouseX + 12, mouseY + 12);
            }
        }
    }
    
    private void renderTexturePreview(GuiGraphics guiGraphics, File textureFile, int x, int y) {
        // Здесь добавить код для рендеринга превью текстуры
        // Можно использовать NativeImage и DynamicTexture
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Обработка горячих клавиш 1-9
        if (keyCode >= GLFW.GLFW_KEY_1 && keyCode <= GLFW.GLFW_KEY_9) {
            int index = keyCode - GLFW.GLFW_KEY_1;
            File[] files = TextureManager.getInstance().getTextureFiles();
            if (files != null && index < files.length) {
                TextureManager.getInstance().loadAndSetTexture(files[index]);
                selectedIndex = index;
                this.onClose();
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    @Override
    public boolean isPauseScreen() {
        return false;
    }
    
    private class TextureButton extends Button {
        private final File textureFile;
        private boolean selected;
        
        public TextureButton(int x, int y, int width, int height, Component message, 
                           File texture, OnPress onPress) {
            super(x, y, width, height, message, onPress, DEFAULT_NARRATION);
            this.textureFile = texture;
        }
        
        public File getTexture() {
            return textureFile;
        }
        
        public void setSelected(boolean selected) {
            this.selected = selected;
        }
        
        @Override
        public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
            super.render(guiGraphics, mouseX, mouseY, partialTicks);
            if (selected) {
                guiGraphics.fill(this.getX(), this.getY(), 
                                this.getX() + 2, this.getY() + height, 0xFF00FF00);
            }
        }
    }
} 